//
//  MainViewController.h
//  CoreTextLabelSample01
//
//  Created by 加藤 on 2012/08/16.
//  Copyright (c) 2012年 eiKato. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "NSAttributedString+Attributes.h"
#import "OHAttributedLabel.h"

@interface MainViewController : UIViewController

@end
