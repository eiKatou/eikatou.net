//
//  main.m
//  CoreTextLabelSample01
//
//  Created by 加藤 瑛 on 2012/08/16.
//  Copyright (c) 2012年 eiKato. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "AppDelegate.h"

int main(int argc, char *argv[])
{
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}
