//
//  MainViewController.m
//  CoreTextLabelSample01
//
//  Created by 加藤 on 2012/08/16.
//  Copyright (c) 2012年 eiKato. All rights reserved.
//

#import "MainViewController.h"

@interface MainViewController ()
@property (weak, nonatomic) IBOutlet OHAttributedLabel *attrLabel;
@property (weak, nonatomic) IBOutlet UILabel *normalLabel;

@end

@implementation MainViewController
@synthesize attrLabel;
@synthesize normalLabel;

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view.
    
    NSString *text = @"明星食品の「すこびる辛麺 超激辛味噌ラーメン」。Text Text 食べてみた感想は、辛い〜！今までで食べたラーメンの中では、トップレベルの辛さ。口は痛いし、汗は出てくるし、話すのもしんどかった。最後に入れた液体ソースが辛い。初めの一口が辛すぎる。最大瞬間辛さでは、ペヤング 激辛やきそばを超えたと思う。 http://gigazine.net/news/20120722-myojo-scoville/";
    self.normalLabel.font = [UIFont fontWithName:@"Helvetica" size:14];
    self.normalLabel.text = text;
    
    NSMutableAttributedString *attrStr = [NSMutableAttributedString attributedStringWithString:text];
    
    NSRange range = [text rangeOfString:@"ペヤング"];
    UIColor *color = [UIColor colorWithRed:0.0f green:1.0f blue:0.0f alpha:1.0f];
    [attrStr setTextColor:color range:range];
    
    [attrStr setFont:[UIFont fontWithName:@"Helvetica" size:14]];
    self.attrLabel.attributedText = attrStr;
    
    NSRange linkRange = [text rangeOfString:@"超激辛味噌ラーメン"];
    NSURL *linkUrl = [NSURL URLWithString:@"http://www.google.com/"];
    [self.attrLabel addCustomLink:linkUrl inRange:linkRange];
    [self.attrLabel setLinkColor:[UIColor redColor]];
    self.attrLabel.underlineLinks = NO;
    
}

- (void)viewDidUnload
{
    [self setAttrLabel:nil];
    [self setNormalLabel:nil];
    [super viewDidUnload];
    // Release any retained subviews of the main view.
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}

@end
