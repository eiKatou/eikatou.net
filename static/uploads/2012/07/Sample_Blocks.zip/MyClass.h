//
//  MyClass.h
//  BlockSample1
//

#import <Foundation/Foundation.h>

@interface MyClass : NSObject

-(void)call;

@end
