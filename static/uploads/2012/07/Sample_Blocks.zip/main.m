//
//  main.m
//  BlockSample1
//

#import <Foundation/Foundation.h>
#import "MyClass.h"

typedef int (^Add)(int x, int y);

int main(int argc, const char * argv[])
{

    @autoreleasepool {
        
        void (^b0)();
        b0 = ^() {
            NSLog(@"block0.");
        };
        b0();
        
        void (^b1)() = ^() {
            NSLog(@"block1.");
        };
        b1();
        
        ^() {
            NSLog(@"block2.");
        }();
        
        void (^add)(int x, int y) = ^(int x, int y) {
            NSLog(@"%d + %d = %d", x, y, x+y);
        };
        add(1, 2);
        
        Add add2 = ^(int x, int y) {
            return x + y;
        };
        int result = add2(10, 2);
        NSLog(@"result = %d", result);
        
        
        MyClass *myClass = [[MyClass alloc] init];
        [myClass call];
        
    }
    return 0;
}


