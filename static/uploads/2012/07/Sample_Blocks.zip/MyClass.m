//
//  MyClass.m
//  BlockSample1
//

#import "MyClass.h"

@implementation MyClass

-(int) calc:(int(^)(int a, int b))process x:(int)x y:(int)y {
    return process(x, y);
}

-(void)call {
    int result = [self calc:^int(int a, int b) {
        return (a + b) / 2;
    } x:10 y:20];
    
    NSLog(@"result = %d", result);
    
    
    int(^process)(int a, int b);
    process = ^(int a, int b) {
        return a + b;  
    };
    int result2 = [self calc:process x:10 y:20];
    NSLog(@"result2 = %d", result2);
}

@end
