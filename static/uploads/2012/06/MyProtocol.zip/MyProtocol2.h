//
//  MyProtocol2.h
//

#import <Foundation/Foundation.h>

@protocol MyProtocolDelegate <NSObject>

@required

-(void) hoge;

@end

@interface MyProtocol2 : NSObject

@property (weak) id<MyProtocolDelegate> delegate;

// public methods
-(void) say:(NSString *)message;

@end
