//
//  MyProtocol.h
//

#import <Foundation/Foundation.h>

@protocol MyProtocol <NSObject>

@required

-(void) foo1;

@optional

-(void) foo2;

@end
