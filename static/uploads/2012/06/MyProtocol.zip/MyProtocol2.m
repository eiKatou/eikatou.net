//
//  MyProtocol2.m
//

#import "MyProtocol2.h"

@implementation MyProtocol2

@synthesize delegate = _delegate;

-(void) say:(NSString *)message {
    NSLog(@"call say method. message:%@", message);
    
    if(self.delegate != nil 
       && [self.delegate conformsToProtocol:@protocol(MyProtocolDelegate)]) {
        [self.delegate hoge];
    }
}

@end
