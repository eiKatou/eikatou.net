//
//  MyClass.m
//

#import "MyClass.h"

@implementation MyClass

-(void) say {
    NSLog(@"call MyClass say");
    
    [self foo1];
    
    MyProtocol2 *myProtocol2 = [[MyProtocol2 alloc] init];
    myProtocol2.delegate = self;
    [myProtocol2 say:@"hello"];
}


-(void) foo1 {
    NSLog(@"call foo1");
}

-(void) foo2 {
    NSLog(@"call foo2");
}

-(void) hoge {
    NSLog(@"call hoge");
}

@end
