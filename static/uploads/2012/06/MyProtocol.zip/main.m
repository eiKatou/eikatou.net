//
//  main.m
//  CommandLineTool2
//

#import <Foundation/Foundation.h>
#import "MyClass.h"

int main(int argc, const char * argv[])
{

    @autoreleasepool {
        
        // insert code here...
        NSLog(@"Hello, World!");
        
        MyClass *myClass = [[MyClass alloc] init];
        [myClass say];
        
    }
    return 0;
}

