//
//  MyClass.h
//

#import <Foundation/Foundation.h>
#import "MyProtocol.h"
#import "MyProtocol2.h"

@interface MyClass : NSObject <MyProtocol, MyProtocolDelegate>

// public methods
-(void) say;

@end
