//
//  MyClass.h
//

#import <Foundation/Foundation.h>

@interface MyClass : NSObject

// property
@property (strong, nonatomic) NSString *name;

// public methods
-(void) say:(NSString *)message;

// public static methods
+(void) say:(NSString *)name message:(NSString *)message;

@end
