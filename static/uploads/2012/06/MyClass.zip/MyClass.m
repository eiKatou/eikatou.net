//
//  MyClass.m
//

#import "MyClass.h"

@interface MyClass ()

// private variable
@property int private;

// private methods (as needed)
-(void) sayName;

@end

@implementation MyClass

// implementation of public and private methods.
@synthesize name = _name;
@synthesize private = _private;

- (id)init
{	
    if(self == [super init]) {
        /* initialization code */
    }
	
    return self;
}

- (void)dealloc
{
    /* alloc init したオブジェクトをreleaseする */
    //    [myData release];
}

-(void) say:(NSString *)message {
}

+(void) say:(NSString *)name message:(NSString *)message {
}

-(void) sayName {
}

@end
