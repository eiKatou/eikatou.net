//
//  ViewController.h
//  TwitterSample1
//
//  Created by 瑛 加藤 on 12/06/24.
//  Copyright (c) 2012年 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <Accounts/ACAccount.h>
#import <Accounts/ACAccountStore.h>
#import <Accounts/ACAccountType.h>
#import <Twitter/TwRequest.h>

@interface ViewController : UIViewController <UITableViewDelegate, UITableViewDataSource>
@property (weak, nonatomic) IBOutlet UITableView *tweetTableView;
@property (weak, nonatomic) IBOutlet UIButton *getAccountButton;
- (IBAction)getAccountTouchUpInside:(id)sender;
@property (weak, nonatomic) IBOutlet UILabel *accountLable;
@property (weak, nonatomic) IBOutlet UIButton *getFavoriteButton;
- (IBAction)getFavoriteTouchUpInside:(id)sender;

@property (strong, nonatomic) ACAccountStore *accountStore;
@property (strong, nonatomic) ACAccount *twAccount;
@end
