//
//  ViewController.m
//  TwitterSample1
//
//  Created by 瑛 加藤 on 12/06/24.
//  Copyright (c) 2012年 __MyCompanyName__. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()

@end

@implementation ViewController
@synthesize tweetTableView;
@synthesize getAccountButton;
@synthesize accountLable;
@synthesize getFavoriteButton;
@synthesize accountStore;
@synthesize twAccount;

- (void)viewDidLoad
{
    [super viewDidLoad];

    tweetTableView.dataSource = self;
    tweetTableView.delegate = self;
}

- (void)viewDidUnload
{
    [self setTweetTableView:nil];
    [self setGetAccountButton:nil];
    [self setGetFavoriteButton:nil];
    [self setAccountLable:nil];
    [super viewDidUnload];
    // Release any retained subviews of the main view.
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    return (interfaceOrientation != UIInterfaceOrientationPortraitUpsideDown);
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return 10;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *CellIdentifier = @"Cell";
    
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
    if (cell == nil) {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleSubtitle
                                      reuseIdentifier:CellIdentifier];
        
        cell.accessoryType = UITableViewCellAccessoryDisclosureIndicator;
        cell.selectionStyle = UITableViewCellSelectionStyleNone;
        
    }
    
    cell.textLabel.text = [NSString stringWithFormat:@"row %d", indexPath.row];
    
    return cell;
}

- (IBAction)getAccountTouchUpInside:(id)sender {
    self.accountStore = [[ACAccountStore alloc] init];
    ACAccountType *accountType = [accountStore accountTypeWithAccountTypeIdentifier:ACAccountTypeIdentifierTwitter];
    
    [accountStore requestAccessToAccountsWithType:accountType withCompletionHandler:^(BOOL granted, NSError *error) {
		if(granted) {
			// Get the list of Twitter accounts.
			NSArray *accountsArray = [accountStore accountsWithAccountType:accountType];
//			[self.accountTableView reloadData];
            
            if ([accountsArray count] > 0) {
                self.twAccount = [accountsArray objectAtIndex:0];
                accountLable.text = twAccount.username;
            } else {
                accountLable.text = [NSString stringWithString:@"Sorry."];
            }
		}
	}];
}

- (IBAction)getFavoriteTouchUpInside:(id)sender {
    NSURL *url = [NSURL URLWithString:@"https://api.twitter.com/1/favorites.json"];
    
    NSMutableDictionary *params = [[NSMutableDictionary alloc] init];
    [params setObject:@"eiKatou" forKey:@"screen_name"];
    [params setObject:@"5" forKey:@"count"];
    
    TWRequest *getFavReq = [[TWRequest alloc] initWithURL:url
                                               parameters:params
                                            requestMethod:TWRequestMethodGET];
    [getFavReq setAccount:twAccount];
    
    [getFavReq performRequestWithHandler:
     ^(NSData *responseData, NSHTTPURLResponse *urlResponse, NSError *error) {
         NSLog(@"HTTP response status: %i", urlResponse.statusCode);
         
         if (responseData) {
             NSError *jsonError;
             NSArray *timeline = [NSJSONSerialization JSONObjectWithData:responseData 
                                                                 options:NSJSONReadingMutableLeaves 
                                                                   error:&jsonError];
             if (timeline) {
//                 NSLog(@"%@", timeline);
                 for (NSDictionary *tweet in timeline) {
                     NSLog(@"tweet :%@", tweet);
                     NSLog(@"tweet text :%@", [tweet objectForKey:@"text"]);
                     NSLog(@"tweet created_at :%@", [tweet objectForKey:@"created_at"]);
                     
                 }

             } else {
                 NSLog(@"%@", jsonError);
             }
         }
	}];
}
@end
