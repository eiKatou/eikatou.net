package net.eikatou.sample.gson;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;

import com.google.gson.Gson;

public class Main3 {
	
	public static void main(String[] args) {
		HttpURLConnection con = null;
		BufferedReader reader = null;
		StringBuilder jsonData = new StringBuilder();
		String urlString = "http://search.twitter.com/search.json?q=eiKatou";
		
		try {
			URL url = new URL(urlString);
			con = (HttpURLConnection) url.openConnection();
			con.setRequestMethod("GET");
			con.setInstanceFollowRedirects(false);
			con.connect();
			
			reader = new BufferedReader(new InputStreamReader(con.getInputStream()));
			String line = reader.readLine();
			while (line != null) {
				jsonData.append(line);
				line = reader.readLine();
			}
			
			System.out.println(jsonData.toString());
			System.out.println();
			
			// JSON to Java
			Gson gson = new Gson();
			SearchResults results = gson.fromJson(jsonData.toString(),
					SearchResults.class);
			
			System.out.println("page = " + results.getPage());
			System.out.println("query = " + results.getQuery());
			System.out.println();
			for (Tweet tweet : results.getResults()) {
				// tweet.getUser() is null.
//				System.out.println("tweet user = " + tweet.getUser().getName());
				System.out.println("id_str = " + tweet.getId_str());
				System.out.println("id = " + tweet.getId());
				System.out.println("text = " + tweet.getText());
				System.out.println();
			}
			
		} catch (Exception e) {
			e.printStackTrace();
		}
		
	}
}
