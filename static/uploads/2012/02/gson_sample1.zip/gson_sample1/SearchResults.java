package net.eikatou.sample.gson;

import java.util.List;

public class SearchResults {
	private int page;
	private String query;
	private List<Tweet> results;
	public int getPage() {
		return page;
	}
	public void setPage(int page) {
		this.page = page;
	}
	public String getQuery() {
		return query;
	}
	public void setQuery(String query) {
		this.query = query;
	}
	public List<Tweet> getResults() {
		return results;
	}
	public void setResults(List<Tweet> results) {
		this.results = results;
	}
}
