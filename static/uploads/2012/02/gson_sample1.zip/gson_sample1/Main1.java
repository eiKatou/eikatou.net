package net.eikatou.sample.gson;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;

import com.google.gson.Gson;

public class Main1 {

	public static void main(String[] args) {
		HttpURLConnection con = null;
		BufferedReader reader = null;
		StringBuilder jsonData = new StringBuilder();
		String urlString = "https://twitter.com/users/show/eiKatou.json";
		
		try {
			URL url = new URL(urlString);
			con = (HttpURLConnection) url.openConnection();
			con.setRequestMethod("GET");
			con.setInstanceFollowRedirects(false);
			con.connect();
			
			reader = new BufferedReader(new InputStreamReader(con.getInputStream()));
			String line = reader.readLine();
			while (line != null) {
				jsonData.append(line);
				line = reader.readLine();
			}
			
			System.out.println(jsonData.toString());
			
			// JSON to Java
			Gson gson = new Gson();
			User user = gson.fromJson(jsonData.toString(),
					User.class);
			
			System.out.println("id = " + user.id);
			System.out.println("screen name = " + user.screen_name);
			System.out.println("name = " + user.name);
			System.out.println("basho = " + user.basho);
			
		} catch (Exception e) {
			e.printStackTrace();
		}
		
	}

}
