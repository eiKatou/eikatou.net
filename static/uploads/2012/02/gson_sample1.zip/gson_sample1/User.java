package net.eikatou.sample.gson;

import com.google.gson.annotations.SerializedName;

public class User {
	String id;
	String screen_name;
	String name;
	@SerializedName("location")
	String basho;

}
