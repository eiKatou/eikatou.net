package net.eikatou.sample.gson;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.lang.reflect.Type;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.Collection;
import java.util.List;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

public class Main2 {
	
	public static void main(String[] args) {
		HttpURLConnection con = null;
		BufferedReader reader = null;
		StringBuilder jsonData = new StringBuilder();
		String urlString = "http://api.twitter.com/1/statuses/user_timeline/115794727.json";
		
		try {
			URL url = new URL(urlString);
			con = (HttpURLConnection) url.openConnection();
			con.setRequestMethod("GET");
			con.setInstanceFollowRedirects(false);
			con.connect();
			
			reader = new BufferedReader(new InputStreamReader(con.getInputStream()));
			String line = reader.readLine();
			while (line != null) {
				jsonData.append(line);
				line = reader.readLine();
			}
			
			System.out.println(jsonData.toString());
			System.out.println();
			
			// JSON to Java
			Gson gson = new Gson();
			Type collectionType = new TypeToken<Collection<Tweet>>(){}.getType();
			List<Tweet> timeLine = gson.fromJson(jsonData.toString(),
					collectionType);
			
			for (Tweet tweet : timeLine) {
				System.out.println("tweet user = " + tweet.getUser().name);
				System.out.println("id_str = " + tweet.getId_str());
				System.out.println("id = " + tweet.getId());
				System.out.println("text = " + tweet.getText());
				System.out.println();
			}
			
		} catch (Exception e) {
			e.printStackTrace();
		}
		
	}
}
