//
//  AppDelegate.h
//  CoreTextLabelSample01
//
//  Created by 加藤 on 2012/08/16.
//  Copyright (c) 2012年 eiKato. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@end
