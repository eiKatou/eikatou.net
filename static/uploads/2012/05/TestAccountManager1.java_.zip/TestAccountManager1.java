package net.eikatou.sample.am1;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;

import org.apache.http.HttpResponse;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.DefaultHttpClient;

import android.accounts.Account;
import android.accounts.AccountManager;
import android.accounts.AccountManagerCallback;
import android.accounts.AccountManagerFuture;
import android.accounts.AuthenticatorException;
import android.accounts.OperationCanceledException;
import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.os.StrictMode;
import android.util.Log;
import android.view.View;
import android.widget.Button;

public class TestAccountManager1 extends Activity {
    /** Called when the activity is first created. */
	static final String TAG="TestAccountManager1";
	AccountManager mAccountManager = null;
	String token = null;

	/** Called when the activity is first created. */
	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.main);
		
		StrictMode.setThreadPolicy(new StrictMode.ThreadPolicy.Builder().permitAll().build());
		
		Button button1 = (Button) findViewById(R.id.button1);
		button1.setOnClickListener(buttonListener);
	}

	@Override
	protected void onResume() {
		super.onResume();
        
		Account[] accounts = null;
		if (mAccountManager == null) {
			mAccountManager = AccountManager.get(this);
		}
		
		accounts = mAccountManager.getAccountsByType("com.google");
		for (Account ac : accounts) {
			Log.d(TAG, ac.toString());
		}
		
		AccountManagerFuture<Bundle> accountManagerFuture = 
			mAccountManager.getAuthToken(accounts[0], 
//        			"cl", 
//					"android", 
//					"ah",		// Google AppEngine 
//					"cl", 		// Google Calendar
//					"mail", 	// Gmail
					"reader", 	// Google Reader
//					"talk", 	// Gtalk
//					"youtube",	// YouTube 
					false, new GetAuthTokenCallback(), null);
	}
    
	private class GetAuthTokenCallback implements AccountManagerCallback<Bundle> {

		static final String TAG="+++ GetAuthTokenCallback";
		@Override
		public void run(AccountManagerFuture<Bundle> arg0) {
			Bundle bundle;
			try {
				bundle = arg0.getResult();
				Intent intent = (Intent) bundle.get(AccountManager.KEY_INTENT);
				if (intent != null) {
					Log.d(TAG, "User Input required");
					startActivity(intent);
				} else {
					Log.d(TAG, "Token = " + bundle.getString(AccountManager.KEY_AUTHTOKEN));
					token = bundle.getString(AccountManager.KEY_AUTHTOKEN);
				}
			} catch (OperationCanceledException e) {
				e.printStackTrace();
			} catch (AuthenticatorException e) {
				e.printStackTrace();
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
	}
	
	private View.OnClickListener buttonListener = new View.OnClickListener() {
		@Override
		public void onClick(View v) {
			loginGoogle(token);
		}
	};
	
	private void loginGoogle(String token) {
		DefaultHttpClient http_client = new DefaultHttpClient();
		
		HttpGet httpGet = new HttpGet("http://www.google.com/reader/atom/user/-/state/com.google/read");
		httpGet.setHeader("Authorization", "GoogleLogin auth="+token);
		HttpResponse response;
		try {
			response = http_client.execute(httpGet);
			InputStream in = response.getEntity().getContent();
			BufferedReader reader = new BufferedReader(new InputStreamReader(in));
			String l = null;
			while ((l = reader.readLine()) != null) {
				Log.i("MyApp", l);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}